// code moved to scrypt-jane.cpp
