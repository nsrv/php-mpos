#ifndef BLAKE_H
#define BLAKE_H

// nothing to see here... move along

#endif // #ifndef BLAKE_H
