#define BFG_GIT_DESCRIBE "bfgminer-4.8.0"
#ifdef VERSION
#  undef VERSION
#endif
#define VERSION "4.8.0"
